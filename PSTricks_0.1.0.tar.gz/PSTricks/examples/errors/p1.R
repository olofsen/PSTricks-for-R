library(PSTricks)

p <- 1

psline(p, 1, 1)

## psline: first argument is not a PSTricks or NULL object
