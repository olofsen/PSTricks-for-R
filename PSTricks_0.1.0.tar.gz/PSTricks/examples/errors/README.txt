The scripts generate common error messages. These should
perhaps be moved to the tests but are included with the
examples because they give examples of error messages.
