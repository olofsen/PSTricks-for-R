PSTricks::geom_dots(PSTricks::PSTricks(),PSTricks::aes(x=wt,y=mpg),mtcars)
