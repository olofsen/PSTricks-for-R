test_that("PSTricks creates a correct object", {

    expect_true(isa(PSTricks(),"PSTricks"))

})
