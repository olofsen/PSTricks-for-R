#!/bin/bash

export R_RCONFIG_FILE="/nas/PSTricks/pstricks.yml"

Rscript renderbookh.R
